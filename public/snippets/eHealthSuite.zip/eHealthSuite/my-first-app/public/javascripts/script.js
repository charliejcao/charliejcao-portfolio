

//index
$(".btn.btn-success").click(function() {
	$("#plans").hide();
	$("#notice").show();
});

$("#notice .btn").click(function() {
	$("#notice").hide();
	$("#info1").show();
});

$("#info1 .btn").click(function() {
	$("#info1").hide();
	$("#info2").show();
});

//information & medicare
$( ".datepicker" ).datepicker({
    changeMonth: true,
    changeYear: true,
    yearRange: "-150:+0"
});

//information & contact
var usStates = [ 'AL', 'AK', 'AS', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'DC', 
                 'FM', 'FL', 'GA', 'GU', 'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 
                 'KY', 'LA', 'ME', 'MH', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 
                 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'MP', 
                 'OH', 'OK', 'OR', 'PW', 'PA', 'PR', 'RI', 'SC', 'SD', 'TN', 
                 'TX', 'UT', 'VT', 'VI', 'VA', 'WA', 'WV', 'WI', 'WY' ];

$.each(usStates, function(val, text){
	$('#residenceState').append(
		$('<option></option>').val(val).html(text)
	);
	$('#mailingState').append(
		$('<option></option>').val(val).html(text)
	);
});

//question
function esrdCheck() {
	if (document.getElementById('yesEsrd').checked) {
		$("#esrdQuestion1").show();
	} else {
		$("#esrdQuestion1").hide();
	}
}